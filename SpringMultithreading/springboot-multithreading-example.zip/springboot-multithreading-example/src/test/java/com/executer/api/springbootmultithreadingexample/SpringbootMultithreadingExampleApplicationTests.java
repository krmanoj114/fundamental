package com.executer.api.springbootmultithreadingexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMultithreadingExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
