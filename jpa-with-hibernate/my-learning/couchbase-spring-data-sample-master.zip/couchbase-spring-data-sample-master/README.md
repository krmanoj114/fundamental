# couchbase-spring-data-sample
An example of how to setup and app using Couchbase, Spring-Boot and Spring-Data

Full documentation of the project here => https://blog.couchbase.com/couchbase-spring-boot-spring-data/
