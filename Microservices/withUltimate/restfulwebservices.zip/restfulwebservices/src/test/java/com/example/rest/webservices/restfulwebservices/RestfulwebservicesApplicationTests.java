package com.example.rest.webservices.restfulwebservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulwebservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
