package com.example.microservices.microservicesx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicesXApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesXApplication.class, args);
	}

}
