package com.manoj.sprintbootcouchbaseexanple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintBootCouchbaseExanpleApplicationTests {

	@Test
	void contextLoads() {
	}

}
